---
name: HyperTest One
description: A quiet testing workspace with floating navigation and stable, traceable records.
colors:
  primary: "#2563eb"
  primary-hover: "#1d4ed8"
  primary-active: "#1e40af"
  canvas: "#f2f5fa"
  surface: "#ffffff"
  shell: "#f6f9ff"
  glass: "rgb(248 251 255 / 82%)"
  ink: "#172338"
  muted: "#526177"
  line: "#dce3ed"
  control-border: "#8190a5"
  placeholder: "#5f6f85"
  navigation-selected: "#e4ecfb"
  tab-selected: "#e0eafb"
  trail: "#edf2fa"
  info: "#0e7490"
  info-bg: "#e7f6fb"
  info-border: "#8cc6d8"
  success: "#22734c"
  warning: "#94620b"
  error: "#b53f40"
  danger-ink: "#a53338"
  warning-ink: "#805507"
  success-tag-ink: "#20613d"
  success-tag-bg: "#edf7ef"
  danger-tag-bg: "#fff1ef"
  warning-tag-bg: "#fff8df"
  info-tag-ink: "#225d83"
  info-tag-bg: "#edf5fb"
  danger-surface: "#fff8f7"
  warning-surface: "#fffcf3"
  table-header: "#f7f9fc"
  table-hover: "#f3f7ff"
  contrast-muted: "#34445c"
typography:
  headline:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "30px"
    fontWeight: 650
    lineHeight: 1.35
    letterSpacing: "-0.03em"
  title:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "25px"
    fontWeight: 600
    lineHeight: 1.4
    letterSpacing: "-0.025em"
  overlay-title:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "18px"
    letterSpacing: "-0.02em"
  body:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "14px"
  reading:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "13px"
    lineHeight: 1.8
  label:
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif'
    fontSize: "12px"
  identifier:
    fontFamily: '"SFMono-Regular", Consolas, "Liberation Mono", monospace'
    fontSize: "11px"
    lineHeight: 1.7
  artifact:
    fontFamily: '"SFMono-Regular", Consolas, "Liberation Mono", monospace'
    fontSize: "12px"
    lineHeight: 1.8
rounded:
  control: "10px"
  compact-surface: "8px"
  surface: "16px"
  modal: "20px"
  drawer: "20px"
  navigation: "22px"
  navigation-compact: "18px"
  section: "12px"
  tag: "6px"
  artifact: "6px"
  pill: "999px"
spacing:
  xs: "4px"
  sm: "8px"
  compact: "12px"
  md: "16px"
  panel-compact: "20px"
  panel: "24px"
  section: "28px"
  lg: "32px"
  wide: "40px"
  page-bottom: "64px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "{colors.surface}"
    rounded: "{rounded.pill}"
    height: "38px"
  button-primary-hover:
    backgroundColor: "{colors.primary-hover}"
  button-primary-active:
    backgroundColor: "{colors.primary-active}"
  button-default:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    height: "38px"
  input:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.control}"
    height: "38px"
  navigation:
    backgroundColor: "{colors.glass}"
    textColor: "{colors.ink}"
    rounded: "{rounded.navigation}"
    height: "68px"
  navigation-solid:
    backgroundColor: "{colors.shell}"
  tag-success:
    backgroundColor: "{colors.success-tag-bg}"
    textColor: "{colors.success-tag-ink}"
    rounded: "{rounded.tag}"
  panel:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.surface}"
    padding: "24px"
  modal:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.ink}"
    rounded: "{rounded.modal}"
    padding: "28px"
  run-section-selected:
    backgroundColor: "{colors.tab-selected}"
    textColor: "{colors.primary-active}"
    rounded: "{rounded.section}"
    padding: "11px 14px"
  evidence-trail:
    backgroundColor: "{colors.trail}"
    textColor: "{colors.ink}"
    rounded: "{rounded.surface}"
    padding: "4px"
---

# Design System: HyperTest One

## Overview

**Creative North Star: "The Floating Testing Reference Index"**

HyperTest One places a quiet, floating control plane above stable testing records. Pale cool canvas, white reading surfaces, graphite text and one blue action accent keep daily QA work clear. Frosted navigation gains definition from an inner light and a soft downward shadow; aligned records, immutable identifiers and adjacent evidence retain the reference-index structure.

The material direction adapts Apple's [Meet Liquid Glass](https://developer.apple.com/videos/play/wwdc2025/219/) and [Get to know the new design system](https://developer.apple.com/videos/play/wwdc2025/356/) to the existing web workspace. The reusable principles are separation between navigation and content, related corner geometry, restrained interaction feedback and legibility across user preferences. The implementation uses CSS translucency and backdrop filtering, with opaque alternatives; native optical refraction is not implemented.

Daily operation determines density and typography. A decision stays close to its reason and evidence, supporting metadata stays readable, and Chinese and English receive the same hierarchy. These rules describe the current checkout's shared stylesheet, Ant Design provider and application components. Product and canonical-state semantics remain governed by PRODUCT.md and the four foundational specifications.

**Key Characteristics:**
- Floating light navigation with a single frosted material per navigation surface.
- Opaque records, forms, decisions and evidence on a pale cool canvas.
- Related rounded geometry, capsule primary actions and quiet control feedback.
- Readable Chinese and English, stable drafts and explicit unknown or recorded-result states.

## Colors

Electric blue supplies action emphasis; pale cool neutrals separate navigation from records. Frontmatter values are normative. Implementation sources are `web/app/globals.css` and `web/app/providers.tsx`.

### Primary
- **Electric Blue** (`primary`, `primary-hover`, `primary-active`): primary actions, links, caret and keyboard focus. Selected navigation uses the darker active ink on a pale blue fill.
- **Cool Navigation Fields** (`navigation-selected`, `tab-selected`, `trail`): current global navigation, selected run section and the connected evidence strip. Preserve their individual roles.

### Secondary
- **Information Teal** (`info`, `info-bg`, `info-border`): informational messages and test-design progress.
- **Recorded State Colors** (`success`, `warning`, `error`): established semantic feedback, reinforced by written labels. Danger and warning decisions use their dedicated ink and opaque surface tokens.
- **Semantic Tag Colors** (`success-tag-*`, `danger-tag-bg`, `warning-tag-bg`, `info-tag-*`): readable foregrounds on restrained state fills. Red and gold tags use the corresponding danger and warning ink tokens; volcano also retains its explicit authored override.

### Neutral
- **Cool Canvas** (`canvas`), **White Surface** (`surface`) and **Table Fields** (`table-header`, `table-hover`): page ground, records and table states. Two shallow cool radial gradients add ambient light near the page top.
- **Frosted Light** (`glass`) and **Solid Light** (`shell`): filtered navigation and its opaque alternative. The glass token retains its authored CSS color format and alpha.
- **Slate Ink** (`ink`), **Quiet Ink** (`muted`) and **Placeholder Ink** (`placeholder`): primary content, readable explanations and input hints. Ant Design receives Quiet Ink through both `colorTextSecondary` and `colorTextDescription`, covering form help, counters, optional marks and guide-step descriptions.
- **Surface Line** (`line`) and **Control Line** (`control-border`): thin structure and visible form boundaries. Higher-contrast preferences strengthen lines with Control Line and change the CSS muted token to `contrast-muted`.

### Named Rules
**The State Has Words Rule.** Color reinforces a written status and, where present, an icon. An accent color or completed workflow never supplies a quality verdict.

Keep the `html .ant-tag.ant-tag-*` selector specificity so Ant preset rules do not silently restore lighter text. Readable descriptions belong to the muted ink role; disabled controls retain their separate component-library state.

## Typography

**Headline and Body Font:** platform system sans with explicit Chinese fallbacks, as recorded in frontmatter.
**Label/Mono Font:** SFMono-Regular, Consolas, Liberation Mono, monospace for keys and artifact content.

**Character:** compact hierarchy for repeated scanning and extended reading. Identifiers distinguish immutable records without competing with human-readable names; numerical counts and table values use tabular figures.

### Hierarchy
- **Headline:** page title; reduces to the mobile title size (25px) at the mobile breakpoint.
- **Title:** quality decision; reduces on mobile (23px). Section headings vary with position (14–17px, weight 600).
- **Overlay Title:** modal and drawer title, with modest negative tracking.
- **Body:** Ant Design's base reading and control size. Longer decision and task text uses the reading role; decision reasons are capped at a readable measure (72ch).
- **Label:** table headers, filters, metadata and evidence navigation. Compact supporting record labels sometimes use smaller type (11px).
- **Identifier / Artifact:** keys and logs; preserve original text, line breaks and wrapping. Artifact content scrolls within a bounded viewport (65vh).

## Layout

The sticky header floats above the page with a separate inset: desktop height (68px), top offset and margin (16px), side gutters (24px), maximum width (1460px) and horizontal padding (22px). Its desktop corner is larger than the contained controls. The centered content container has its own maximum width (1400px), side gutters (48px), top padding (40px) and bottom padding (64px).

Navigation progresses from Projects to a project's runs to one run. Context links preserve that hierarchy. At desktop widths (992px upward), run sections use a left index (180px wide, 8px inner padding) separated from pane content by a gap (24px). Below that boundary, the index becomes a horizontal strip with the library's overflow controls. Overview groups use a proportional split (1.25:1), with normal gaps (20px or 24px) tightening below 1200px (16px). Dense tables own horizontal scrolling; long identifiers wrap inside their content region.

At 991px and below, content gutters reduce (20px) and top padding tightens (28px). At 640px and below, content gutters reduce again (16px) and top padding tightens (24px); the header uses a smaller height (60px), top offset and margin (10px), side gutters (10px), inner horizontal padding (12px) and compact corner. Heading actions stack, overview panels become one column, and four evidence links form a two-by-two grid. Coverage counts move above the measures. Supporting workflow labels disappear below 1200px. Mobile keeps the home brand, guide and language controls while page context links support navigation.

The spacing vocabulary combines small control gaps with comfortable panel and section separation; it is not a mandatory single-step grid. Typical panel padding is the panel step, tightening to the compact panel step on smaller layouts. Textarea counters reserve a separate bottom line (24px margin) before explanatory Form.Item text. Preserve that reservation when adding counted fields.

**The Action Hierarchy Rule.** Keep the complete testing cycle as the principal run action; group secondary planning, execution, gate and input actions in the existing More actions disclosure.

## Elevation & Depth

Depth belongs to navigation and immediate control feedback. Header and run-section navigation share a fine inner highlight and diffuse downward shadow. White content surfaces use fill and a thin border without an added ambient shadow. Primary buttons have a small colored shadow at rest and a slightly larger hover shadow; default buttons retain no resting shadow. Modals, drawers and menus use their library overlay behavior.

### Shadow Vocabulary
- **Navigation glass:** `var(--ht-glass-shadow)` — `0 8px 30px rgb(34 58 98 / 9%), 0 2px 5px rgb(34 58 98 / 4%), inset 0 1px 0 rgb(255 255 255 / 96%), inset 0 0 0 1px rgb(255 255 255 / 72%)`.
- **Primary action, rest:** `0 3px 8px rgb(37 99 235 / 16%)`.
- **Primary action, hover:** `0 5px 14px rgb(37 99 235 / 22%)`.
- **Navigation hover:** `0 2px 7px rgb(34 58 98 / 7%)`.
- **Selected run section:** `inset 0 1px 0 rgb(255 255 255 / 90%), 0 2px 5px rgb(34 58 98 / 5%)`.

**The Navigation Material Rule.** Apply backdrop filtering only to the shared header and run-section navigation. Keep decisions, evidence, tables, forms and reading surfaces opaque; controls within a glass surface use fills rather than a second glass layer.

The two navigation surfaces use a fixed filter (`blur(24px) saturate(130%)`) only inside the filter-support query. Their base material is the solid shell, so browsers without filter support retain a readable surface. Reduced transparency and increased contrast replace the filter with solid fill and a stronger inset edge. Forced colors use system Canvas, CanvasText and Highlight, with filtering and shadows removed. Do not animate backdrop blur.

## Shapes

Related corners create the shared form language: major content surfaces use the surface radius; standard controls use the control radius; modal and drawer bodies use their overlay radii. The desktop header uses the navigation radius and tightens to the compact navigation radius on mobile. Run navigation uses the compact navigation radius, with section controls using the section radius. Primary actions, current header links, counts and header utility controls are capsules.

Compact table wrappers, alerts and policy blocks retain their compact-surface radius. Semantic tags and artifact blocks retain smaller corners; these are local content treatments, not defaults for new controls. Borders are normally one pixel. The evidence strip has the surface radius and a small inner inset; its internal buttons have related corners (11px), while dividers keep the group connected. Project avatars use the section radius.

## Components

### Buttons
Primary actions use electric blue, white text, capsule corners, the shared control height and stronger text (weight 600, 18px inline padding). Default actions are white with a control border and standard control corners; link and text variants keep their Ant Design behavior. Loading and disabled states guard repeated work while keeping context. Hover and active treatments use the configured blue tokens; enabled primary press scales slightly (0.98). All authored state transitions are short (180ms) with the shared ease.

### Inputs / Fields
Use labeled opaque inputs and selects, vertical form layout, readable placeholder ink and visible validation messages. The shared theme sets the standard control height and radius. Readable help, optional labels, counters and guide descriptions receive the muted description token. Counted textareas reserve their own bottom line before help text.

Keep drafts on the current page when dialogs close. Creation runs through source, requirements, environment, policy and review steps; language changes retain the draft, original PRD and current step. Invalid submission focuses the first failing field. Pending mutations guard dismissal and repeated submission as the existing forms do.

### Chips
Tags show a written status. Green, red, gold, blue/geekblue and volcano retain explicit semantic overrides; neutral tags serve metadata and states that do not imply success. General tags can wrap long content. Project status labels remain on one line so English Archived stays intact in its status cell. A verified evidence tag does not imply a passing run.

### Cards / Containers
White bordered containers use the surface radius and normal panel spacing. Danger and warning decisions add opaque semantic fill and border. Table headings are lightly tinted, rows have a cool hover field and vertical cell padding (20px). Empty, loading and failed reads occupy the same region as their eventual content and offer a relevant next action or retry.

### Navigation
The brand returns home; the header identifies project/run context and exposes guide and language controls. Current global navigation combines `aria-current`, darker blue ink and a pale capsule fill. Hover adds a light fill and a small shadow. The locale control uses a thin translucent fill within the header, with no second backdrop filter.

Run tabs sit on one frosted navigation surface. Selected and active text use the darker blue token, paired with the selected section fill; hover uses the configured hover ink. Tabs retain selection per run in session storage and through language changes. Evidence shortcuts select the relevant section and focus its selected tab. Keep the library's keyboard behavior, including Home/End and Enter activation. Details open in solid drawers so users retain run context.

### Decision and evidence trail
The lead decision is the highest-sequence verdict whose status is `FINAL` and scope is `TEST_RUN`. Draft, revoked and narrower verdicts remain in history. With no eligible verdict, show waiting or unavailable text; task completion never substitutes for a decision. Historical execution failures may precede the current verdict and must retain that distinction.

The opaque evidence trail links to executions, findings, evidence and verdicts, carrying counts or a dash when data has not loaded. Unknown coverage is labeled Unknown rather than displayed as zero. Failed refreshes retain loaded records with a retry warning. Agent activity remains supporting information; trusted Runner execution and evidence provide formal facts.

### Overlays
Modal and drawer bodies remain opaque with related overlay corners. Modals use generous internal padding (28px desktop, 24px vertically and 20px horizontally on mobile). The right drawer floats inside a viewport inset (12px), with a lightly tinted header and an opaque reading area. Close controls are capsules; long URLs, hashes and descriptions wrap within the available width.

### Accessibility and motion
Maintain a skip link, visible keyboard focus, accessible control names, semantic headings and written statuses in both languages. The authored focus outline uses the primary accent (3px with a 3px offset). Ant Design also receives the primary accent through `colorPrimaryBorder` so its controls retain strong library focus treatment. Clamped overview descriptions retain links to the full content. No accessibility conformance level is inferred from these implementation rules.

Control and navigation feedback transitions color, fill, border, shadow or a small press transform; the filter remains fixed. The shared easing is `cubic-bezier(.16, 1, .3, 1)`. Reduced motion removes authored transitions and the primary press transform. Run tab-pane animation is explicitly disabled.

The provider initializes reduced motion to true, mounting Ant's motion wrapper from the first render, then reads `matchMedia('(prefers-reduced-motion: reduce)')` and listens for changes. Preserve this stable provider structure and the theme motion token so changing preferences does not insert a wrapper and remount pages or discard drafts. Do not substitute a blanket third-party animation override for provider-level handling. Solid-material preference and unsupported-filter fallbacks remain part of the same navigation component contract.

## Do's and Don'ts

### Do:
- **Do** use the pale cool canvas, floating light navigation, blue actions and opaque reading surfaces for new operating pages.
- **Do** keep decisions, reasons, record identity and evidence reachable in one reading path.
- **Do** preserve bilingual drafts, selected run sections, loaded results and immutable history during updates.
- **Do** give readable help the muted description token and reserve a separate line for textarea counters.
- **Do** pair state color with readable labels, preserve visible keyboard focus and keep short project status labels intact.
- **Do** retain solid navigation fallbacks and the stable reduced-motion provider structure.
- **Do** distinguish unknown, unavailable, zero, task completion and formal quality decisions.

### Don't:
- **Don't** stack glass on glass or apply backdrop filtering to decisions, evidence, tables, forms or reading surfaces.
- **Don't** animate blur or add decorative entrance sequences to routine testing work.
- **Don't** infer release readiness from task success, coverage counts or an Agent report.
- **Don't** let dense tables or long identifiers create whole-page horizontal overflow.
- **Don't** replace explicit semantic tag overrides with lower-specificity preset styling.
- **Don't** add noisy imagery, neon body text or promotional display typography to this operating workspace.
- **Don't** ship synthetic acceptance records in product routes or present frontend fixture checks as a real testing cycle.
